# Define constants for the screen width and height

class Screen:
    width = 800
    height = 600
