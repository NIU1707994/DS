from gameSprites import GameSprite

class LandscapeSprites(GameSprite):
    def __init__(self):
        super(LandscapeSprites, self).__init__()